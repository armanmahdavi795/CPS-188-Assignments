#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <time.h>

void format_date(int year, int day_of_year, char *date_out) {
    struct tm date = {0};
    date.tm_year = year - 1900;
    date.tm_mday = day_of_year;
    mktime(&date);
    strftime(date_out, 11, "%y-%m-%d", &date);
}

double sum(double array[], int size) {
    if(size == 0)
        return 0;
    return array[size - 1] + sum(array, size - 1);
}

double largest(double array[], int size)
{
	int i=0, place;
	double large=0;
	while(i<=size)
	{
		if(array[i]>large)
		{
			large=array[i];
			place=i;
		}
		i++;
	}
	return(place);
}

double smallest(double array[], int size)
{
	int i=0, place;
	double small=100;
	while(i<=size)
	{
		if(array[i]==0)
		break;
		else
		if(array[i]<small)
		{
			small=array[i];
			place=i;
		}
		i++;
	}
	return(place);
}

const char *lake_names[] = {"Superior", "Michigan", "Huron", "Erie", "Ontario", "StClair"};
const char *input_files[] = {"g2021_2022_ice.dat.txt", "g2022_2023_ice.dat.txt", "g2023_2024_ice.dat.txt"};
const int input_years[] = {2021, 2022, 2023};


int main() {
    {
        for (int f = 0; f < 3; f++) {
            FILE *input_file = fopen(input_files[f], "r");
            FILE *lake_outputs[6];
            for (int i = 0; i < 6; i++) {
                char filename[64];
                sprintf(filename, "%s_%d.dat", lake_names[i], input_years[f]);
                lake_outputs[i] = fopen(filename, "w");
            }

            char *line = NULL;
            size_t line_length = 0;

            while (getline(&line, &line_length, input_file) != -1) {
                char *yeah = line;
                while (*yeah && isspace((unsigned char)*yeah)) yeah++;
                if (!isdigit((unsigned char)*yeah)) continue;

                int year, day_of_year;
                float lake_values[7];

                int fields = sscanf(line, "%d %d %f %f %f %f %f %f %f",
                                    &year, &day_of_year,
                                    &lake_values[0], &lake_values[1], &lake_values[2],
                                    &lake_values[3], &lake_values[4], &lake_values[5],
                                    &lake_values[6]);

                if (fields != 9) continue;

                char date_string[11];
                format_date(year, day_of_year, date_string);

                for (int i = 0; i < 6; i++) {
                    if (lake_outputs[i]) {
                        fprintf(lake_outputs[i], "%s %.2f\n", date_string, lake_values[i]);
                    }
                }
            }

            for (int i = 0; i < 6; i++) {
                if (lake_outputs[i]) {
                    fclose(lake_outputs[i]);
                }
            }

        }
    }

    
        FILE* lakes2122;
        FILE* lakes2223;
        FILE* lakes2324;
        double sup23[366], mich23[366], hur23[366], erie23[366], ont23[366], stc23[366], tot23[366];
        double sup24[366], mich24[366], hur24[366], erie24[366], ont24[366], stc24[366], tot24[366];
        double sup22[366], mich22[366], hur22[366], erie22[366], ont22[366], stc22[366], tot22[366];
        double sup21[366], mich21[366], hur21[366], erie21[366], ont21[366], stc21[366], tot21[366];
        double avg21, avg22, avg23, avg24;
        double fullavg[6];
        char buffer[1000];
        char x[100], toplake[7][20] = {"Lake Superior", "Lake Michigan", "Lake Huron", "Lake Erie", "Lake Ontario", "Lake St. Clair", "ERROR"};
        int count21=0, count22=0, count23x=0, count24=0, i;
        int yr, day, place;

        lakes2324 = fopen("g2023_2024_ice.dat.txt", "r");
        if (!lakes2324) {
            fprintf(stderr, "Could not open g2023_2024_ice.dat.txt\n");
        } else {
            /* skip 8 lines */
            for(i=0; i<8; i++) {
                fgets(buffer, sizeof(buffer), lakes2324);
            }
        }
        for(i=0; i<=366; i++) {/*set all array values to 0 to avoid non numerical values*/
            sup23[i]=mich23[i]=hur23[i]=erie23[i]=ont23[i]=stc23[i]=tot23[i]=0;
            sup24[i]=mich24[i]=hur24[i]=erie24[i]=ont24[i]=stc24[i]=tot24[i]=0;
        }

/*scan values in data file as strings and convert to floats before sending to their respectve arrays*/
        if (lakes2324) {
            while(fscanf(lakes2324, "%d %d", &yr, &day)==2) {
                if(yr==2023) {
                    fscanf(lakes2324, " %s", x);
                    sup23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    mich23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    hur23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    erie23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    ont23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    stc23[day]=atof(x);
                    fscanf(lakes2324, " %s", x);
                    tot23[day]=atof(x);
                    count23x++;
                } else
                if(yr==2024) {
                    fscanf(lakes2324, "%s", x);
                    sup24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    mich24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    hur24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    erie24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    ont24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    stc24[day]=atof(x);
                    fscanf(lakes2324, "%s", x);
                    tot24[day]=atof(x);
                    count24++;
                } else {
                    printf("invalid date");
                    break;
                }
            }
            fclose(lakes2324);

            if(yr==2023) {
                count23x++;
            } else if(yr==2024) {
                count24++;
            }
        }


/*use sum function and counts to compute and print average values while sending them to average arrays for question 2*/
        printf("Average Ice Concetration (By Percentage) of each Great Lake\n");
	printf("____________________________________________________________\n\n");
	printf("   Lake     2023     2024\n");
	printf("___________________________\n");

    avg23 = sum(sup23, 366)/count23x;
    avg24 = sum(sup24, 366)/count24;
    fullavg[0]=(count23x*avg23+count24*avg24)/(count23x+count24);
    printf("Superior    %3.3lf    %3.3lf\n", avg23, avg24);
    avg23 = sum(mich23, 366)/count23x;
    avg24 = sum(mich24, 366)/count24;
	fullavg[1]=(count23x*avg23+count24*avg24)/(count23x+count24);
    printf("Michigan    %3.3lf    %3.3lf\n", avg23, avg24); 
	avg23 = sum(hur23, 366)/count23x;
    avg24 = sum(hur24, 366)/count24;
	fullavg[2]=(count23x*avg23+count24*avg24)/(count23x+count24);
	printf("Huron       %3.3lf    %3.3lf\n", avg23, avg24);
	avg23 = sum(erie23, 366)/count23x;
	avg24 = sum(erie24, 366)/count24; 
	fullavg[3]=(count23x*avg23+count24*avg24)/(count23x+count24);
	printf("Erie        %3.3lf    %3.3lf\n", avg23, avg24); 
	avg23 = sum(ont23, 366)/count23x;
	avg24 = sum(ont24, 366)/count24;
	fullavg[4]=(count23x*avg23+count24*avg24)/(count23x+count24);
	printf("Ontario     %3.3lf    %3.3lf\n", avg23, avg24); 
	avg23 = sum(stc23, 366)/count23x;
	avg24 = sum(stc24, 366)/count24;
	fullavg[5]=(count23x*avg23+count24*avg24)/(count23x+count24);
	printf("St. Clair   %3.3lf    %3.3lf\n", avg23, avg24); 
	avg23 = sum(tot23, 366)/count23x;
	avg24 = sum(tot24, 366)/count24;
	printf("GL Total    %3.3lf    %3.3lf\n", avg23, avg24); 

        printf("\n\n\nQuestion 2:\n\n");


/*find index for highest and lowest ice concentrations and printing accordingly*/
	place = largest(fullavg, 6);
	printf("The lake with the highest ice concentration average is %s with an ice concentration of %3.3lf percent.\n", toplake[place], fullavg[place]);
	
	place = smallest(fullavg, 6);
	printf("The lake with the lowest ice concentration average is %s with an ice concentration of %3.3lf percent.\n", toplake[place], fullavg[place]);
	
	
	// Question 3 ********************************************************************
	// REQUIRES QUESTION 1 TO WORK
	
	printf("\n\nQuestion 3:");
	double supmax = 0, michmax = 0, hurmax = 0, eriemax = 0, ontmax = 0, stcmax = 0;
	int daymaxsup, yearmaxsup, daymaxmich, yearmaxmich, daymaxhur, yearmaxhur, daymaxerie, yearmaxerie, daymaxont, yearmaxont, daymaxstc, yearmaxstc;
	for (int z=329; z<=365; z++) { // find max ice % for lakes in 2023 and record date
	    if (sup23[z] > supmax) {
	        supmax = sup23[z];
	        daymaxsup = z;
	        yearmaxsup = 2023;
	    }
	    if (mich23[z] > michmax) {
	        michmax = mich23[z];
	        daymaxmich = z;
	        yearmaxmich = 2023;
	    }
	    if (hur23[z] > hurmax) {
	        hurmax = hur23[z];
	        daymaxhur = z;
	        yearmaxhur = 2023;
	    }
	    if (erie23[z] > eriemax) {
	        eriemax = erie23[z];
	        daymaxerie = z;
	        yearmaxerie = 2023;
	    }
	    if (ont23[z] > ontmax) {
	        ontmax = ont23[z];
	        daymaxont = z;
	        yearmaxont = 2023;
	    }
	    if (stc23[z] > stcmax) {
	        stcmax = stc23[z];
	        daymaxstc = z;
	        yearmaxstc = 2023;
	    }
	    // printf("Lake 2023 %d: %.2lf\n", z, sup23[z]);
	}
	
	for (int z=1; z<=116; z++) { // find max ice % for lakes in 2024 and record date (overwrites 2023 max % if 2024 is higher)
	    if (sup24[z] > supmax) {
	        supmax = sup24[z];
	        daymaxsup = z;
	        yearmaxsup = 2024;
	    }
	    if (mich24[z] > michmax) {
	        michmax = mich24[z];
	        daymaxmich = z;
	        yearmaxmich = 2024;
	    }
	    if (hur24[z] > hurmax) {
	        hurmax = hur24[z];
	        daymaxhur = z;
	        yearmaxhur = 2024;
	    }
	    if (erie24[z] > eriemax) {
	        eriemax = erie24[z];
	        daymaxerie = z;
	        yearmaxerie = 2024;
	    }
	    if (ont24[z] > ontmax) {
	        ontmax = ont24[z];
	        daymaxont = z;
	        yearmaxont = 2024;
	    }
	    if (stc24[z] > stcmax) {
	        stcmax = stc24[z];
	        daymaxstc = z;
	        yearmaxstc = 2024;
	    }
	    
	    // printf("Lake 2024 %d: %.2lf\n", z, sup24[z]);
	}
	
	// variables for determining ties
	int suptie[2], michtie[2], hurtie[2], erietie[2], onttie[2], stctie[2];
	suptie[1] = 0, michtie[1] = 0, hurtie[1] = 0, erietie[1] = 0, onttie[1], stctie[1] = 0;
	
	for (int z=1; z<=116; z++) { // Goes through days again and compares with max ice % to see if there are ties
	    if (z != daymaxsup && sup24[z] == supmax)
	        suptie[1] = z, suptie[0] = yearmaxsup;
	    if (z != daymaxmich && mich24[z] == michmax)
	        michtie[1] = z, michtie[0] = yearmaxmich;
	    if (z != daymaxhur && hur24[z] == hurmax)
	        hurtie[1] = z, hurtie[0] = yearmaxhur;
	    if (z != daymaxerie && erie24[z] == eriemax)
	        erietie[1] = z, erietie[0] = yearmaxerie;
	    if (z != daymaxont && ont24[z] == ontmax)
	        onttie[1] = z, onttie[0] = yearmaxont;
	    if (z != daymaxstc && stc24[z] == stcmax)
	        stctie[1] = z, stctie[0] = yearmaxstc;
	}
	
	// display results
	printf("\n\nSuperior ice %%:  Highest: %5.2lf%%, year: %d, day: %d", supmax, yearmaxsup, daymaxsup);
	if (suptie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", supmax, yearmaxsup, suptie[1]);
	printf("\n\nMichigan ice %%:  Highest: %5.2lf%%, year: %d, day: %d", michmax, yearmaxmich, daymaxmich);
	if (michtie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", michmax, yearmaxmich, michtie[1]);
	printf("\n\nHuron ice %%:     Highest: %5.2lf%%, year: %d, day: %d", hurmax, yearmaxhur, daymaxhur);
	if (hurtie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", hurmax, yearmaxhur, hurtie[1]);
	printf("\n\nErie ice %%:      Highest: %5.2lf%%, year: %d, day: %d", eriemax, yearmaxerie, daymaxerie);
	if (erietie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", eriemax, yearmaxerie, erietie[1]);
	printf("\n\nOntario ice %%:   Highest: %5.2lf%%, year: %d, day: %d", ontmax, yearmaxont, daymaxont);
	if (onttie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", ontmax, yearmaxont, onttie[1]);
	printf("\n\nSt. Clair ice %%: Highest: %5.2lf%%, year: %d, day: %d", stcmax, yearmaxstc, daymaxstc);
	if (stctie[1] != 0)
	    printf("\n                     Tie: %5.2lf%%, year: %d, day: %d", stcmax, yearmaxstc, stctie[1]);
	
	// Question 4 **********************************************************
	
	printf("\n\nQuestion 4:");
	
	
	double lakesmax[6] = {supmax, michmax, hurmax, eriemax, ontmax, stcmax}; // put results of max ice % into array
	double maxall = 0;
    for (int i=0; i<6; i++) { // check which ice % is highest and store result
        if (lakesmax[i] > maxall)
            maxall = lakesmax[i];
    }
    
    // display results and print out any ties if there are any
    if (maxall == supmax)
        printf("\n\nHighest ice %% out of all lakes: Superior: %.2lf%%, year: %d, day: %d", maxall, yearmaxsup, daymaxsup);
    if (maxall == michmax)
        printf("\n\nHighest ice %% out of all lakes: Michigan: %.2lf%%, year: %d, day: %d", maxall, yearmaxmich, daymaxmich);
    if (maxall == hurmax)
        printf("\n\nHighest ice %% out of all lakes: Huron: %.2lf%%, year: %d, day: %d", maxall, yearmaxhur, daymaxhur);
    if (maxall == eriemax)
        printf("\n\nHighest ice %% out of all lakes: Erie: %.2lf%%, year: %d, day: %d", maxall, yearmaxerie, daymaxerie);
    if (maxall == ontmax)
        printf("\n\nHighest ice %% out of all lakes: Ontario: %.2lf%%, year: %d, day: %d", maxall, yearmaxont, daymaxont);
    if (maxall == stcmax)
        printf("\n\nHighest ice %% out of all lakes: St. Clair: %.2lf%%, year: %d, day: %d", maxall, yearmaxstc, daymaxstc);

        printf("\n");

	
	

        printf("\n\n\nQuestion 7:\n\n");
        count23x = 0;

/*same as queston 1 but with two files and an extra year taken into account*/
        lakes2122 = fopen("g2021_2022_ice.dat.txt", "r");
        lakes2223 = fopen("g2022_2023_ice.dat.txt", "r");

        if (!lakes2122)  fprintf(stderr, "Could not open g2021_2022_ice.dat.txt\n");
        if (!lakes2223)  fprintf(stderr, "Could not open g2022_2023_ice.dat.txt\n");

        if (lakes2122 && lakes2223) {
            for(i=0; i<8; i++) {
                fgets(buffer, sizeof(buffer), lakes2122);
                fgets(buffer, sizeof(buffer), lakes2223);
            }
        }

        for(i=0; i<=366; i++) {
            sup23[i]=mich23[i]=hur23[i]=erie23[i]=ont23[i]=stc23[i]=tot23[i]=0;
            sup22[i]=mich22[i]=hur22[i]=erie22[i]=ont22[i]=stc22[i]=tot22[i]=0;
            sup21[i]=mich21[i]=hur21[i]=erie21[i]=ont21[i]=stc21[i]=tot21[i]=0;
        }

        if (lakes2122) {
            while(fscanf(lakes2122, "%d %d", &yr, &day)==2) {
                if(yr==2021) {
                    fscanf(lakes2122, " %s", x);
                    sup21[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    mich21[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    hur22[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    erie21[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    ont21[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    stc21[day] = atof(x);
                    fscanf(lakes2122, " %s", x);
                    tot21[day] = atof(x);
                    count21++;
                } else if(yr==2022) {
                    fscanf(lakes2122, "%s", x);
                    sup22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    mich22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    hur22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    erie22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    ont22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    stc22[day] = atof(x);
                    fscanf(lakes2122, "%s", x);
                    tot22[day] = atof(x);
                    count22++;
                } else {
                    printf("invalid date");
                    break;
                }
            }
            if (yr==2023) {
                count23x++;
            } else if(yr==2022) {
                count22++;
            } else if(yr==2021) {
                count21++;
            }
        }

        if (lakes2223) {
            while(fscanf(lakes2223, "%d %d", &yr, &day)==2) {
                if(yr==2022) {
                    fscanf(lakes2223, "%s", x);
                    sup22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    mich22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    hur22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    erie22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    ont22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    stc22[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    tot22[day] = atof(x);
                    count22++;
                } else if(yr==2023) {
                    fscanf(lakes2223, "%s", x);
                    sup23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    mich23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    hur23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    erie23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    ont23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    stc23[day] = atof(x);
                    fscanf(lakes2223, "%s", x);
                    tot23[day] = atof(x);
                    count23x++;
                } else {
                    printf("invalid date");
                    break;
                }
            }
        }

        if (lakes2122) fclose(lakes2122);
        if (lakes2223) fclose(lakes2223);

        printf("Average Ice Concetration (By Percentage) of each Great Lake by percent \n");
        printf("_______________________________________________________________________\n\n");
        printf("   Lake      2021      2022      2023\n");
        printf("______________________________________\n");

        avg21 = sum(sup21, 366)/count21;
        avg22 = sum(sup22, 366)/count22;
        avg23 = sum(sup23, 366)/count23x;
        printf("Superior    %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(mich21, 366)/count21;
        avg22 = sum(mich22, 366)/count22;
        avg23 = sum(mich23, 366)/count23x;
        printf("Michigan    %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(hur21, 366)/count21;
        avg22 = sum(hur22, 366)/count22;
        avg23 = sum(hur23, 366)/count23x;
        printf("Huron       %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(erie21, 366)/count21;
        avg22 = sum(erie22, 366)/count22;
        avg23 = sum(erie23, 366)/count23x;
        printf("Erie        %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(ont21, 366)/count21;
        avg22 = sum(ont22, 366)/count22;
        avg23 = sum(ont23, 366)/count23x;
        printf("Ontario     %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(stc21, 366)/count21;
        avg22 = sum(stc22, 366)/count22;
        avg23 = sum(stc23, 366)/count23x;
        printf("St. Clair   %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);

        avg21 = sum(tot21, 366)/count21;
        avg22 = sum(tot22, 366)/count22;
        avg23 = sum(tot23, 366)/count23x;
        printf("GL Total    %6.3lf    %6.3lf    %6.3lf\n", avg21, avg22, avg23);


        printf("Please run q5.gnu to generate the graphs for the 6 lakes sepately and run q6.gnu to have them all on 1 graph. \nAs well as run q8.gnu to generate the graphs for 3 years for the 6 lakes. \n\n");

    return 0;
}
